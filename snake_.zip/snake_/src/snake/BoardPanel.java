package snake;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JPanel;

public class BoardPanel extends JPanel {

    //The number of columns and rows on the board. (Should be odd so we can start in the center).
    public static final int Columns = 35;
    public static final int Rows = 35;
    //The size of each dot or tile size.
    public static final int TILE_SIZE = 15;
    // The font to draw the text with.
    private static final Font FONT = new Font(" ", Font.BOLD, 20);
    // The SnakeGame instance.
    private SnakeGame game;
    // The array of tiles that make up this board.
    private TileType[] tiles;
    
    
 //------------------------------------Create Borad and site size ---------------------------------------------
    // Creates a new BoardPanel instance.
    public BoardPanel(SnakeGame game) {
        this.game = game;
        this.tiles = new TileType[Rows * Columns];
        //size of the bord 
        setPreferredSize(new Dimension(Columns * TILE_SIZE, Rows * TILE_SIZE));
        setBackground(Color.black);
    }

    public void clearBoard() {
        for (int i = 0; i < tiles.length; i++) {
            tiles[i] = null;
        }
    }

    public void setTile(Point point, TileType type) {
        setTile(point.x, point.y, type);
    }

    public void setTile(int x, int y, TileType type) {
        tiles[y * Rows + x] = type;
    }

    //gets..
    public TileType getTile(int x, int y) {
        return tiles[y * Rows + x];
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        // Loop through each tile on the board and draw it if it
        // is not null.
        for (int x = 0; x < Columns; x++) {
            for (int y = 0; y < Rows; y++) {
                TileType type = getTile(x, y);
                if (type != null) {
                    drawTile(x * TILE_SIZE, y * TILE_SIZE, type, g);
                }
            }
        }
////---------------------------------------------------------------------------
        // Show a message on the screen based on the current game state.
        if (game.isGameOver() || game.isNewGame() || game.isPaused()) {
            g.setColor(Color.WHITE);
            // Get the wordes in the center of the board.
            int centerX = getWidth() / 2;
            int centerY = getHeight() / 2;
            String Message1 = null;
            String Message2 = null;

            if (game.isNewGame()) {
                Message1 = "It's Snake Game! ";
                Message2 = "Please Press Enter to Start";
            } else if (game.isGameOver()) {
                Message1 = "OOPS, Game Over!";
                Message2 = "Press Enter to Restart";
            } else if (game.isPaused()) {
                Message1 = "Paused";
                Message2 = "Press P to Resume";
            }

            // Set the message font and draw the messages in the center of the board.
            g.setFont(FONT);
            g.drawString(Message1, centerX - g.getFontMetrics().stringWidth(Message1) / 2, centerY - 50);
            g.drawString(Message2, centerX - g.getFontMetrics().stringWidth(Message2) / 2, centerY + 50);
        }
    }

  ////--------------------------------Draw snake-------------------------------------------
 
    private void drawTile(int x, int y, TileType type, Graphics g) {

        switch (type) {

            case Fruit:
                g.setColor(Color.RED);
                g.fillOval(x + 2, y + 2, TILE_SIZE - 4, TILE_SIZE - 4);
                break;

            case SnakeBody:
                g.setColor(Color.ORANGE);
                g.fillRect(x, y, TILE_SIZE, TILE_SIZE);
                break;

            case SnakeHead:
                //Fill the tile in with green.
                g.setColor(Color.ORANGE);
                g.fillRect(x, y, TILE_SIZE, TILE_SIZE);

        }

    }
}
