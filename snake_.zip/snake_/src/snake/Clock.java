
package snake;

public class Clock {
	
	
	 // The number of milliseconds that make up one cycle.
	private float millisPerCycle;
	
	 // The last time that the clock was updated (used for calculating the
	  //delta time).
	private long lastUpdate;
	
	//The number of cycles that have elapsed and have not yet been polled.
	private int elapsedCycles;
	
	//The amount of excess time towards the next elapsed cycle.
	private float excessCycles;
	
	private boolean isPaused;
	
	 // Creates a new clock and sets it's cycles-per-second.
	// cyclesPerSecond The number of cycles that elapse per second.
	
	public Clock(float cyclesPerSecond) {
		setCyclesPerSecond(cyclesPerSecond);
		reset();
	}
	
	
	 // Sets the number of cycles that elapse per second.
	// cyclesPerSecond The number of cycles per second.
	public void setCyclesPerSecond(float cyclesPerSecond) {
		this.millisPerCycle = (1.0f / cyclesPerSecond) * 1000;
	}
	
	
	 // Resets the clock to 0
	 // the last update time will be reset to the current time, and the
	 // paused flag will be set to false.
	public void reset() {
		this.elapsedCycles = 0;
		this.excessCycles = 0.0f;
		this.lastUpdate = getCurrentTime();
		this.isPaused = false;
	}
	

	public void update() {
		//Get the current time and calculate the delta time.
		long currUpdate = getCurrentTime();
		float delta = (float)(currUpdate - lastUpdate) + excessCycles;
		
		//Update the number of elapsed and excess ticks if we're not paused.
		if(!isPaused) {
			this.elapsedCycles += (int)Math.floor(delta / millisPerCycle);
			this.excessCycles = delta % millisPerCycle;
		}
		
		//Set the last update time for the next update cycle.
		this.lastUpdate = currUpdate;
	}

	public void setPaused(boolean paused) {
		this.isPaused = paused;
	}

	public boolean isPaused() {
		return isPaused;
	}
	
	public boolean hasElapsedCycle() {
		if(elapsedCycles > 0) {
			this.elapsedCycles--;
			return true;
		}
		return false;
	}
 
	private static final long getCurrentTime() {
		return (System.nanoTime() / 1000000L);
	}

}
