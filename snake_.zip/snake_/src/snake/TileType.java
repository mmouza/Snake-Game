
package snake;


  public enum TileType {

	Fruit,
	
	SnakeHead,
	
	SnakeBody
	
}
